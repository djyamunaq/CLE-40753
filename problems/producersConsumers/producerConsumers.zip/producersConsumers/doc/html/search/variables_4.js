var searchData=
[
  ['nstorepos_48',['nStorePos',['../fifo_8c.html#ad573dee4f2c7bdfbb0bf48e703c14313',1,'nStorePos():&#160;producersConsumers.c'],['../producers_consumers_8c.html#ad573dee4f2c7bdfbb0bf48e703c14313',1,'nStorePos():&#160;producersConsumers.c']]]
];
