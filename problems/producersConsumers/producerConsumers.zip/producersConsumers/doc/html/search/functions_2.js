var searchData=
[
  ['initialization_36',['initialization',['../fifo_8c.html#a7130de79f30be88872ddaad48572ee14',1,'fifo.c']]]
];
