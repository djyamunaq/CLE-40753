var searchData=
[
  ['ri_49',['ri',['../fifo_8c.html#aa10722d44c6b6470e1829bdd4cb3c9dc',1,'fifo.c']]]
];
