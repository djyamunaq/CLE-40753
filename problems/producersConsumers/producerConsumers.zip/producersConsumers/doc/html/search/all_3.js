var searchData=
[
  ['get_5fdelta_5ftime_7',['get_delta_time',['../producers_consumers_8c.html#a7dba4c1427615881764917d1eb9f5c8f',1,'producersConsumers.c']]],
  ['getval_8',['getVal',['../fifo_8c.html#ad3c8df257d0076db8efa36259d9e35ec',1,'getVal(unsigned int consId):&#160;fifo.c'],['../fifo_8h.html#ad3c8df257d0076db8efa36259d9e35ec',1,'getVal(unsigned int consId):&#160;fifo.c']]]
];
