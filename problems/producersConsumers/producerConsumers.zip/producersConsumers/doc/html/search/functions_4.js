var searchData=
[
  ['printusage_38',['printUsage',['../producers_consumers_8c.html#add7b265b1786a2217ce8613e4bf60a89',1,'producersConsumers.c']]],
  ['producer_39',['producer',['../producers_consumers_8c.html#ac26df6bcb65c313e44b65fd23e71e38d',1,'producersConsumers.c']]],
  ['putval_40',['putVal',['../fifo_8c.html#acf62b959d24fb0fd3eefad3d439529ff',1,'putVal(unsigned int prodId, unsigned int val):&#160;fifo.c'],['../fifo_8h.html#acf62b959d24fb0fd3eefad3d439529ff',1,'putVal(unsigned int prodId, unsigned int val):&#160;fifo.c']]]
];
