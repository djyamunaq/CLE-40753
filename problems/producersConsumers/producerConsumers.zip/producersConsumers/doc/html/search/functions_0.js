var searchData=
[
  ['consumer_33',['consumer',['../producers_consumers_8c.html#a5be402e48c00277b76df1fd4a6d4f130',1,'producersConsumers.c']]]
];
